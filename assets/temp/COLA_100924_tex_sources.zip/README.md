# SLE 2017 FlowSpec paper

## Build instructions

* Use `make bib` to download the bibliographies.
* Use `make` afterwards to build the document. 
* You need to call `make` thrice to get the citations right when you build the first time or when you change the citations in certain ways. <3 LaTeX
